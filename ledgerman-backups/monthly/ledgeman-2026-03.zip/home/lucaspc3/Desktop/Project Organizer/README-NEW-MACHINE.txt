═══════════════════════════════════════════════════════════════
  LEDGEMAN — NEW MACHINE SETUP GUIDE
  Construction Management Software by PMs for PMs
═══════════════════════════════════════════════════════════════

WHAT YOU NEED ON THE NEW COMPUTER
──────────────────────────────────
1. Python 3.8 or newer
   Download: https://python.org/downloads
   (On Linux: sudo apt install python3 python3-pip)

2. A web browser (Chrome, Firefox, Edge — any)

3. The zip file: LEDGEMAN-PORTABLE-[date].zip


STEP 1 — EXTRACT THE ZIP
──────────────────────────
Unzip LEDGEMAN-PORTABLE-[date].zip to a folder, e.g.:
  Windows:  C:\Ledgeman\
  Mac/Linux: ~/Ledgeman/

You should see these folders inside:
  ledgeman/           ← frontend app
  ledgeman-backend/   ← backend API + database
  ledgeman-admin/     ← LittleShield super admin console
  ledgeman-site/      ← marketing website
  START-ALL.sh        ← launcher (Mac/Linux)
  START-ALL.bat       ← launcher (Windows)
  SETUP.sh            ← one-time setup (Mac/Linux)


STEP 2 — FIRST-TIME SETUP (run ONCE)
──────────────────────────────────────
Mac / Linux:
  Open Terminal → cd to the folder → run:
    chmod +x SETUP.sh ledgeman-backend/SETUP.sh START-ALL.sh
    ./ledgeman-backend/SETUP.sh

Windows:
  Open Command Prompt → cd to the folder → run:
    python -m pip install -r ledgeman-backend\requirements.txt

This installs Flask, PyJWT, and flask-cors.
It also creates the database and your super-admin key.


STEP 3 — START LEDGEMAN (every time)
──────────────────────────────────────
Mac / Linux:
  ./START-ALL.sh

Windows:
  Double-click START-ALL.bat
  OR open Command Prompt and run: START-ALL.bat

The app opens automatically at: http://localhost:8765
The backend runs at:            http://localhost:5001


STEP 4 — OPEN LITTLESHIELD ADMIN CONSOLE
──────────────────────────────────────────
1. Open ledgeman-admin/index.html in your browser
2. Enter your super-admin key
   Key is stored in: ledgeman-backend/.superadmin_key
   (open that file with any text editor to see the key)


TRANSFERRING EXISTING DATA
──────────────────────────
If you have an existing database with company data:
  Copy:  ledgeman-backend/ledgeman.db
  To the same location on the new machine.
  Your companies, workers, and all data will carry over.

If starting fresh — just let SETUP.sh create a new empty database.


PORTS USED
───────────
  8765  — Frontend app (the Ledgeman interface)
  5001  — Backend API (Flask)

If either port is in use, edit START-ALL.sh (or .bat) and change
the PORT numbers at the top.


TROUBLESHOOTING
───────────────
Backend won't start:
  Check: /tmp/ledgeman-backend.log
  Make sure Python 3 and pip packages are installed.
  Run: python3 ledgeman-backend/server.py
  and look for error messages.

"Module not found" error:
  Run: pip3 install -r ledgeman-backend/requirements.txt

App shows blank page / old data:
  Hard-refresh: Ctrl+Shift+R (Windows/Linux) or Cmd+Shift+R (Mac)

Port already in use:
  Kill whatever is using it:
  Linux/Mac: fuser -k 5001/tcp && fuser -k 8765/tcp
  Windows:   netstat -ano | findstr :5001  (then taskkill /PID [number] /F)

Can't connect to backend (sync fails):
  Make sure both START-ALL.sh commands are running (backend + frontend).
  Check that API_BASE in ledgeman/app/js/data.js says localhost:5001.


KEY FILES TO BACK UP REGULARLY
────────────────────────────────
  ledgeman-backend/ledgeman.db        ← ALL company data
  ledgeman-backend/.superadmin_key    ← your private admin key

Everything else can be rebuilt from source.


CONTACT & SUPPORT
──────────────────
  Email:   aegiszeus2@gmail.com
  Product: Ledgeman Construction Management
  Price:   $25/month per company

═══════════════════════════════════════════════════════════════
