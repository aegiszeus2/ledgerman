@echo off
:: ═══════════════════════════════════════════════════════════════
::  Ledgeman — START ALL (Windows)
::  Double-click this file to start Ledgeman on Windows.
:: ═══════════════════════════════════════════════════════════════

SET BACKEND_PORT=5001
SET APP_PORT=8765
SET SCRIPT_DIR=%~dp0
SET BACKEND_DIR=%SCRIPT_DIR%ledgeman-backend
SET APP_DIR=%SCRIPT_DIR%ledgeman\app

echo.
echo [Ledgeman] Starting backend API on port %BACKEND_PORT%...
start "Ledgeman Backend" cmd /k "cd /d "%BACKEND_DIR%" && python server.py"

timeout /t 3 /nobreak >nul

echo [Ledgeman] Starting frontend on port %APP_PORT%...
start "Ledgeman Frontend" cmd /k "cd /d "%APP_DIR%" && python -m http.server %APP_PORT%"

timeout /t 2 /nobreak >nul

echo [Ledgeman] Opening in browser...
start http://localhost:%APP_PORT%

echo.
echo =====================================
echo  Ledgeman is running!
echo  App:      http://localhost:%APP_PORT%
echo  Backend:  http://localhost:%BACKEND_PORT%
echo  Close the two terminal windows to stop.
echo =====================================
echo.
pause
