#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Ledgeman — START ALL
#  Launches backend API + frontend app in one command.
#  Run from the folder containing ledgeman/ and ledgeman-backend/
# ═══════════════════════════════════════════════════════════════

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/ledgeman-backend"
APP_DIR="$SCRIPT_DIR/ledgeman/app"
BACKEND_PORT=5001
APP_PORT=8765

echo ""
echo "🏗️  Starting Ledgeman..."
echo "════════════════════════════════════════"

# ── Kill anything already on these ports ─────────────────────
fuser -k ${BACKEND_PORT}/tcp 2>/dev/null && echo "  ↻ Cleared port $BACKEND_PORT" || true
fuser -k ${APP_PORT}/tcp     2>/dev/null && echo "  ↻ Cleared port $APP_PORT"     || true
sleep 0.5

# ── Start backend ─────────────────────────────────────────────
echo ""
echo "▸ Starting backend API (port $BACKEND_PORT)..."
cd "$BACKEND_DIR"
python3 server.py > /tmp/ledgeman-backend.log 2>&1 &
BACKEND_PID=$!
echo "  PID: $BACKEND_PID"

# Wait for backend to respond
for i in {1..15}; do
    sleep 0.5
    if curl -s http://localhost:${BACKEND_PORT}/api/health >/dev/null 2>&1; then
        echo "  ✓ Backend ready"
        break
    fi
    if [ $i -eq 15 ]; then
        echo "  ✗ Backend failed to start. Check /tmp/ledgeman-backend.log"
        exit 1
    fi
done

# ── Start frontend ────────────────────────────────────────────
echo ""
echo "▸ Starting frontend (port $APP_PORT)..."
python3 -c "
import http.server, socketserver, os
os.chdir('$APP_DIR')
class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-store,no-cache,must-revalidate')
        self.send_header('Pragma','no-cache')
        super().end_headers()
    def log_message(self,*a): pass
with socketserver.TCPServer(('',${APP_PORT}),H) as s:
    s.serve_forever()
" > /tmp/ledgeman-frontend.log 2>&1 &
FRONTEND_PID=$!

sleep 0.5
echo "  PID: $FRONTEND_PID"
echo "  ✓ Frontend ready"

# ── Open in browser ───────────────────────────────────────────
echo ""
APP_URL="http://localhost:${APP_PORT}"
echo "════════════════════════════════════════"
echo "✅  Ledgeman is running!"
echo ""
echo "  App:           $APP_URL"
echo "  Backend API:   http://localhost:${BACKEND_PORT}"
echo "  LittleShield:  open ledgeman-admin/index.html"
echo "  Backend log:   /tmp/ledgeman-backend.log"
echo ""
echo "  Press Ctrl+C to stop everything."
echo "════════════════════════════════════════"
echo ""

# Open in browser if available
if command -v xdg-open &>/dev/null; then
    xdg-open "$APP_URL" 2>/dev/null &
elif command -v open &>/dev/null; then
    open "$APP_URL" 2>/dev/null &
elif command -v firefox &>/dev/null; then
    firefox "$APP_URL" 2>/dev/null &
fi

# ── Trap Ctrl+C to kill both processes ───────────────────────
trap "echo ''; echo 'Stopping Ledgeman...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Done.'; exit 0" INT TERM

# Keep script alive
wait $BACKEND_PID
