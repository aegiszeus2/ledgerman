// Worker Invite Setup
// Shown when the app URL contains #invite/TOKEN
// Handles: PIN setup + optional 2FA (TOTP) configuration

window.WorkerInvite = {
    _token: null,
    _worker: null,

    show(token) {
        const self = this;
        const invite = AppData.getInvite(token);

        if (!invite || invite.used) {
            self._showInvalid('This invite link is invalid or has already been used.');
            return;
        }

        // Check expiry (7 days)
        const created = new Date(invite.createdAt);
        const ageMs = Date.now() - created.getTime();
        if (ageMs > 7 * 24 * 60 * 60 * 1000) {
            self._showInvalid('This invite link has expired. Ask your admin for a new one.');
            return;
        }

        const worker = AppData.getWorker(invite.workerId);
        if (!worker) {
            self._showInvalid('Worker account not found. Please contact your admin.');
            return;
        }

        self._token = token;
        self._worker = worker;
        self._renderSetup();
    },

    _showInvalid(message) {
        document.getElementById('app').innerHTML =
            '<div class="login-screen">' +
                '<div class="login-card">' +
                    '<div style="font-size:2.5rem;margin-bottom:12px">🔗</div>' +
                    '<h2>Invalid Invite</h2>' +
                    '<p class="text-muted">' + (message || 'This invite link is not valid.') + '</p>' +
                    '<button class="btn btn-primary btn-block" id="inviteGoLogin">Go to Login</button>' +
                '</div>' +
            '</div>';
        document.getElementById('inviteGoLogin').addEventListener('click', function() {
            window.location.hash = '';
            window.App.showLogin();
        });
    },

    _renderSetup() {
        const self = this;
        const worker = self._worker;

        document.getElementById('app').innerHTML =
            '<div class="login-screen">' +
                '<div class="login-card" style="max-width:440px">' +
                    '<div style="font-size:2.5rem;margin-bottom:8px">👷</div>' +
                    '<h2>Welcome, ' + Utils.escapeHtml(worker.name) + '!</h2>' +
                    '<p class="text-muted" style="margin-bottom:24px">Set up your account to start submitting work.</p>' +

                    '<form id="inviteSetupForm" novalidate>' +

                        '<div class="form-group" style="margin-bottom:14px">' +
                            '<label>Choose a PIN <span style="font-size:.8rem;color:var(--text2)">(4–6 digits)</span></label>' +
                            '<div style="position:relative">' +
                                '<input type="password" class="form-control pin-input" id="invitePin"' +
                                '   placeholder="Enter PIN" maxlength="6" inputmode="numeric"' +
                                '   pattern="[0-9]{4,6}" required autocomplete="new-password"' +
                                '   style="padding-right:56px">' +
                                '<button type="button" id="toggleInvitePin" class="btn-ghost btn-sm"' +
                                '   style="position:absolute;right:6px;top:50%;transform:translateY(-50%);font-size:.75rem">Show</button>' +
                            '</div>' +
                        '</div>' +

                        '<div class="form-group" style="margin-bottom:20px">' +
                            '<label>Confirm PIN</label>' +
                            '<input type="password" class="form-control pin-input" id="invitePinConfirm"' +
                                'placeholder="Re-enter PIN" maxlength="6" inputmode="numeric"' +
                                'pattern="[0-9]{4,6}" required autocomplete="new-password">' +
                        '</div>' +

                        '<div class="form-group" style="margin-bottom:20px">' +
                            '<label>Your Email Address <span style="font-size:.8rem;color:var(--text2)">(for notifications)</span></label>' +
                            '<input type="email" class="form-control" id="inviteEmail"' +
                                'placeholder="your@email.com" autocomplete="email">' +
                        '</div>' +

                        '<div style="border-top:1px solid var(--border);padding-top:16px;margin-bottom:16px">' +
                            '<label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:.95rem">' +
                                '<input type="checkbox" id="enable2FA" style="width:18px;height:18px">' +
                                '<span>' +
                                    '<strong>Enable 2-Factor Authentication</strong><br>' +
                                    '<span style="font-size:.8rem;color:var(--text2)">Requires Google Authenticator or Authy app</span>' +
                                '</span>' +
                            '</label>' +
                        '</div>' +

                        '<div id="twoFASetup" style="display:none;margin-bottom:20px">' +
                            '<div style="background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:16px">' +
                                '<p style="margin:0 0 12px;font-size:.9rem"><strong>Step 1.</strong> Scan this QR code with your authenticator app:</p>' +
                                '<div id="qrContainer" style="text-align:center;margin-bottom:12px;min-height:196px;display:flex;align-items:center;justify-content:center">' +
                                    '<div style="color:var(--text2);font-size:.85rem">Generating…</div>' +
                                '</div>' +
                                '<p style="font-size:.8rem;color:var(--text2);margin:0 0 4px">Can\'t scan? Enter this key manually in the app:</p>' +
                                '<code id="totpSecretDisplay" style="display:block;font-size:.85rem;background:var(--bg);padding:6px 10px;border-radius:4px;word-break:break-all;letter-spacing:1px;cursor:pointer" title="Click to copy"></code>' +
                                '<p style="font-size:.85rem;margin:14px 0 4px"><strong>Step 2.</strong> Enter the 6-digit code to verify:</p>' +
                                '<input type="text" class="form-control" id="verifyTotpCode"' +
                                '   placeholder="000 000" maxlength="7" inputmode="numeric"' +
                                '   style="letter-spacing:6px;text-align:center;font-size:1.3rem">' +
                            '</div>' +
                        '</div>' +

                        '<div class="form-error" id="inviteError" style="display:none;margin-bottom:12px"></div>' +
                        '<button type="submit" class="btn btn-primary btn-block" style="padding:14px">Set Up Account</button>' +

                    '</form>' +
                '</div>' +
            '</div>';

        // Toggle PIN visibility
        document.getElementById('toggleInvitePin').addEventListener('click', function() {
            const inp = document.getElementById('invitePin');
            if (inp.type === 'password') {
                inp.type = 'text';
                this.textContent = 'Hide';
            } else {
                inp.type = 'password';
                this.textContent = 'Show';
            }
        });

        // 2FA toggle — generate secret and QR code on demand
        let totpSecret = null;
        document.getElementById('enable2FA').addEventListener('change', async function() {
            const div = document.getElementById('twoFASetup');
            if (this.checked) {
                div.style.display = 'block';
                if (!totpSecret) {
                    totpSecret = TOTP.generateSecret();
                    const issuer = AppData.getCompanyName() || 'Ledgeman';
                    const otpUrl = TOTP.getOtpAuthUrl(totpSecret, worker.name, issuer);
                    const qrApiUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=192x192&data=' + encodeURIComponent(otpUrl);

                    document.getElementById('totpSecretDisplay').textContent = totpSecret;
                    document.getElementById('qrContainer').innerHTML =
                        '<img src="' + qrApiUrl + '" alt="QR Code"' +
                        ' style="width:192px;height:192px;border-radius:8px;border:4px solid #fff"' +
                        ' onerror="this.style.display=\'none\';document.getElementById(\'qrFallback\').style.display=\'block\'">' +
                        '<div id="qrFallback" style="display:none;font-size:.8rem;color:var(--text2);padding:12px">QR unavailable — enter the key manually above.</div>';
                }

                // Click to copy secret
                document.getElementById('totpSecretDisplay').addEventListener('click', function() {
                    navigator.clipboard.writeText(totpSecret).then(function() {
                        Utils.showToast('Secret key copied!');
                    }).catch(function() {});
                });
            } else {
                div.style.display = 'none';
            }
        });

        // Form submit
        document.getElementById('inviteSetupForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const pin = document.getElementById('invitePin').value;
            const pinConfirm = document.getElementById('invitePinConfirm').value;
            const use2FA = document.getElementById('enable2FA').checked;
            const errEl = document.getElementById('inviteError');
            errEl.style.display = 'none';

            // Validate PIN
            if (!pin || pin.length < 4 || pin.length > 6 || !/^\d+$/.test(pin)) {
                errEl.textContent = 'PIN must be 4–6 digits.';
                errEl.style.display = 'block';
                return;
            }
            if (pin !== pinConfirm) {
                errEl.textContent = 'PINs do not match.';
                errEl.style.display = 'block';
                return;
            }

            // Check PIN uniqueness (exclude this worker's current PIN)
            const duplicate = AppData.getWorkers().find(function(w) {
                return w.pin === pin && w.id !== self._worker.id;
            });
            if (duplicate) {
                errEl.textContent = 'This PIN is already taken. Please choose a different one.';
                errEl.style.display = 'block';
                return;
            }

            // Validate TOTP setup if 2FA is enabled
            if (use2FA) {
                if (!totpSecret) {
                    errEl.textContent = 'Please enable 2FA and scan the QR code before continuing.';
                    errEl.style.display = 'block';
                    return;
                }
                const code = (document.getElementById('verifyTotpCode').value || '').replace(/\s/g, '');
                if (code.length !== 6 || !/^\d+$/.test(code)) {
                    errEl.textContent = 'Enter the 6-digit code from your authenticator app.';
                    errEl.style.display = 'block';
                    return;
                }
                const valid = await TOTP.verifyToken(totpSecret, code);
                if (!valid) {
                    errEl.textContent = 'Code is incorrect or expired. Make sure your phone\'s time is accurate.';
                    errEl.style.display = 'block';
                    return;
                }
            }

            // Save worker updates
            const updatedWorker = AppData.getWorker(self._worker.id);
            updatedWorker.pin = pin;
            updatedWorker.twoFAEnabled = use2FA;
            const emailVal = (document.getElementById('inviteEmail').value || '').trim();
            if (emailVal) updatedWorker.email = emailVal;
            if (use2FA) {
                updatedWorker.totpSecret = totpSecret;
            } else {
                delete updatedWorker.totpSecret;
            }
            AppData.saveWorker(updatedWorker);

            // Mark invite as used
            const invite = AppData.getInvite(self._token);
            if (invite) {
                invite.used = true;
                invite.usedAt = new Date().toISOString();
                AppData.saveInvite(invite);
            }

            // Clear the invite hash from the URL without a reload
            history.replaceState(null, '', window.location.pathname + window.location.search);

            AppData.addAuditLog(updatedWorker.name, 'Invite Accepted', updatedWorker.name + (use2FA ? ' — 2FA enabled' : ''));
            Utils.showToast('Account set up successfully!');

            // Log worker in automatically
            window.App.currentUser = { type: 'worker', name: updatedWorker.name, id: updatedWorker.id };
            window.App.startWorkerPortal(updatedWorker);
        });
    }
};
