# Ledgeman

## Purpose & Goals
Standalone construction management web app — Procore-style, built for small contractors.
Started as the Belfort invoicing tool. Now a standalone product with SaaS potential.

## Status: Active — Building

## Stack
- Pure HTML/CSS/JS (no framework, no backend, no server needed)
- LocalStorage + IndexedDB for persistence
- Fully offline, runs in any browser

## Modules
### Admin Portal
- Dashboard — KPIs, quick actions, recent activity
- Projects — job tracking, project detail view
- Approvals — review & approve worker time submissions
- Invoices — create, send, track payment
- Expenses — review worker-submitted expenses
- Vendors — vendor contacts and spend tracking
- Clients — client database
- Workers — user management, PIN auth
- Photos — job site photo log
- Reports — financial and job reports
- Settings — company setup, backup/restore, branding
- Help — in-app documentation

### Worker Portal
- Home — active jobs, quick submit
- Time Entry — log hours, expenses, photos by project
- History — past submissions
- Help — worker guide

## Key Files
- Code: `~/.openclaw/workspace/ledgeman/`
- Entry point: `~/.openclaw/workspace/ledgeman/index.html`

## Vision
- Phase 1: Fully working app for Belfort's own use
- Phase 2: Package as SaaS — sell to other small contractors ($30-$80/mo)
- Phase 3: AI features (auto-invoice drafting, cost forecasting)

## Action Items
- [ ] Resume build session — identify next incomplete module
- [ ] Test full flow: worker login → time entry → admin approval → invoice
- [ ] Polish UI and fix any broken modules
- [ ] Define Phase 2 SaaS plan
